#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"

int main(int argc, char **argv)
{
  printf(1,"I understand Operating system.\n");
  printf(1,"I understand Operating system.\n");
  printf(1,"i understand Operating system.\n");
  printf(1,"I love to work on OS.\n");
  printf(1,"I love to work on OS.\n");
  printf(1,"Thanks xv6\n");
  exit();
}

