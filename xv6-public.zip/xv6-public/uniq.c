#include "types.h"
#include "fs.h"
#include "user.h"
#include "stat.h"

char buffer[24800];

// Constants to improve code readability
#define MAX_LINES 30
#define MAX_LINE_LENGTH 100

int incr(int lineCount)
{

 lineCount=lineCount+1;
return lineCount;
}
void uniq(int fileDescriptor, char *fileName, int ignoreCase, int onlyDuplicates, int giveCount)
{
    int lineCounter = 0;
    char tempLine[MAX_LINE_LENGTH];
    int bufferIndex = 0;
    int lineIndex = 0;
    char *lines[MAX_LINES];
    int readResult = 0;
    int lineCount = 0;
    int tempIndex = 0;
    int size = 0;
    int comparisonResult = 0;
    int cmpIndex = 0;
    int counter = 0;
    int lineCounterArray[MAX_LINES] = {0};

    while ((readResult = read(fileDescriptor, buffer, sizeof(buffer))) > 0)
    {
        bufferIndex = 0;
        while (bufferIndex < readResult)
        {
            if (buffer[bufferIndex] == '\n')
                 lineCount=incr(lineCount);
            bufferIndex=incr(bufferIndex);
        }
        lineIndex = 0;
        while (buffer[lineIndex] != '\n')
        {
            counter=incr(counter);
            tempLine[lineIndex] = buffer[lineIndex];
            lineIndex++;
        }

        tempLine[lineIndex] = '\0';
        lineCounterArray[0] = 1;
        lines[0] = malloc((counter + 1) * sizeof(char *));

        lineIndex=0;
        while(lineIndex < counter + 1)
        {
          lines[size][lineIndex] = tempLine[lineIndex];
          lineIndex=incr(lineIndex);
        }

        lines[size][lineIndex] = '\0';
        cmpIndex = lineIndex;
        while (lineCounter < lineCount - 1)
        {
            lineCounter++;
            counter = 0;
            for (lineIndex = cmpIndex; buffer[lineIndex] != '\n'; lineIndex++)
            {
                counter++;
                tempLine[tempIndex++] = buffer[lineIndex];
            }
            tempLine[tempIndex] = '\0';
            cmpIndex = cmpIndex + counter + 1;
            tempIndex = 0;
            if (ignoreCase)
            {
                lineIndex = 0;
                int areEqual = 1;
                int lineIndex=0;
                while(lines[size][lineIndex])
                {
                    char char1 = lines[size][lineIndex];
                    char char2 = tempLine[lineIndex];
                   int smallcmop=(int)char1;
                    if(smallcmop>97)
       		     {
                     char1=char1-32;
                     }
                     smallcmop=(int)char2;
                    if(smallcmop>97)
                      char2=char2-32;
                    if (char1 != char2)
                    {
                        areEqual = 0;
                        break;
                    }
                   lineIndex++;
                }
                 switch(areEqual){
                   case 0:
                          size++;
                          lines[size] = malloc((counter + 1) * sizeof(char *));
                          for (comparisonResult = 0; comparisonResult < counter; comparisonResult++)
                          {
                          lines[size][comparisonResult] = tempLine[comparisonResult];
                          }
                          lines[size][comparisonResult] = '\0';
                          lineCounterArray[size] = 1;
                          break;
                    default:
                             lineCounterArray[size] = lineCounterArray[size] + 1;
                             break;
                              }
                           
            }
            else
            {
                if (strcmp(lines[size], tempLine) != 0)
                {
                    size++;
                    lines[size] = malloc((counter + 1) * sizeof(char *));
                    for (lineIndex = 0; lineIndex < counter; lineIndex++)
                    {
                        lines[size][lineIndex] = tempLine[lineIndex];
                    }
                    lines[size][lineIndex] = '\0';
                    lineCounterArray[size] = 1;
                }
                else
                {
                    lineCounterArray[size] = lineCounterArray[size] + 1;
                }
            }
        }
    }
    int k;
    if (giveCount)
    {
        k = 0;
        while (k < size + 1)
        {
            printf(1, "%d %s \n", lineCounterArray[k], lines[k]);
            k++;
        }
    }
    else if (onlyDuplicates)
    {
        k = 0;
        while (k < size + 1)
        {
            if (lineCounterArray[k] > 1)
            {
                printf(1, "%s \n", lines[k]);
                lineCounterArray[k] = 0;
            }
            k++;
        }
    }
    else
    {
        k = 0;
        while (k < size + 1)
        {
            printf(1, "%s \n", lines[k]);
            k++;
        }
    }
}

int main(int argc, char **argv)
{
    int ignoreCase = 0, onlyDuplicates = 0, giveCount = 0;
    int fileDescriptor;
    if (argc <= 1)
    {
        uniq(0, "", ignoreCase, onlyDuplicates, giveCount);
        exit();
    }
    switch(argc)
    {
      case 2: 
            if ((fileDescriptor = open(argv[1], 0)) < 0)
            {
            printf(1, "uniq: cannot open %s\n", argv[1]);
            exit();
            }
            uniq(fileDescriptor, argv[1], ignoreCase, onlyDuplicates, giveCount);
            close(fileDescriptor);
            exit();
            break;    

    
      default:    
           
             
               if((argv[1][0]==45 && argv[1][1]==99)||(argv[1][0]==45 && argv[1][1]==67))
                 giveCount=1; 
               if((argv[1][0]==45 && argv[1][1]==100)||(argv[1][0]==45 && argv[1][1]==68))
                 onlyDuplicates = 1;
               if((argv[1][0]==45 && argv[1][1]==105)||(argv[1][0]==45 && argv[1][1]==73))
                 ignoreCase = 1;          

            int k = 2;
            while (k < argc)
           {
            if ((fileDescriptor = open(argv[k], 0)) < 0)
            {
                printf(1, "uniq: cannot open %s\n", argv[k]);
                exit();
            }
            uniq(fileDescriptor, argv[k], ignoreCase, onlyDuplicates, giveCount);
            close(fileDescriptor);
            k++;
            }
            exit();
    }
}
