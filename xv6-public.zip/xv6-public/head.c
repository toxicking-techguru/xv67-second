#include "types.h"
#include "stat.h"
#include "user.h"

#define DEFAULT_LINES 14


void head(int frd, int spaces) {
    char buf[512];
    int nof;
    int cnt = 0;

    while ((nof = read(frd, buf, sizeof(buf))) > 0 && cnt < spaces) {
          int i=0;
        while(i < nof && cnt < spaces)
          {
             if(buf[i] =='\n')
               cnt++;
            printf(1,"%c" , buf[i]);
            i++;
          }
    
    }
}
void argc_call_0(int num_lines)
{
 head(0, num_lines);
}
int incrt(int argc)
{
argc=argc-1;
return argc;
}

int main(int argc, char *argv[]) {
     
       int given_line = DEFAULT_LINES;    
    printf(1, "Head command is getting executed in user mode.\n");
   int nFlag=0;
    if (argc > 1 && argv[1][0] == '-' && argv[1][1] == 'n') {
       
        given_line = atoi(argv[2]);
        nFlag=1;
    }

    if (argc == 1) {
         
      argc_call_0(given_line);
       
    } 
 else {

       
            int flag=3;
            if(nFlag==0) {
               flag=1;
            }
            while(flag<argc)
            {
            int fd = open(argv[flag], 0);
           
            if (fd < 0) {
                printf(2, "Head Could Not  open '%s'\n", argv[flag]);
                continue;
                        }
            if (argc > 2) {
               
                printf(1, "* %s *\n", argv[flag]);
                          }
             flag++;
            head(fd, given_line);
            close(fd);
            }
    }

    exit();
}
